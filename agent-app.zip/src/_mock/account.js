// ----------------------------------------------------------------------

export const account = {
  displayName: 'John Doe',
  email: 'demo@agenapp.com',
  photoURL: '/assets/images/avatars/avatar_25.jpg',
};
